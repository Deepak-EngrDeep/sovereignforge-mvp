// app/layout.js
// Root layout — sets up fonts, Tailwind base styles, and the page <head>.

import "./globals.css";

export const metadata = {
  title: "SovereignForge MVP · CSV Cleaner for Factories",
  description: "Upload messy factory data. Get clean, masked, deduplicated CSV in seconds.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        {/* Google Fonts: Bebas Neue (industrial display) + DM Sans (body) */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
        <link rel="icon" href="/favicon.png" />
      </head>
      <body className="font-body bg-forge-dark text-white antialiased">
        {children}
      </body>
    </html>
  );
}
