// ─────────────────────────────────────────────────────────────────────────────
// components/FileUploader.jsx
// Handles: file input → parse (CSV or XLSX) → clean → preview → download
// ─────────────────────────────────────────────────────────────────────────────
"use client"; // Required by Next.js App Router for interactive components

import { useState, useRef } from "react";
import Papa from "papaparse";           // CSV parser (runs in browser)
import * as XLSX from "xlsx";           // XLSX parser (runs in browser)
import { cleanData } from "../utils/cleaner";

// ── WhatsApp CTA number ───────────────────────────────────────────────────────
// Replace +91XXXXXXXXXX with your real WhatsApp business number
const WHATSAPP_NUMBER = "91XXXXXXXXXX";

export default function FileUploader() {
  // ── Component state ──────────────────────────────────────────────────────────
  const [status,   setStatus]   = useState(""); // status / error message
  const [isError,  setIsError]  = useState(false);
  const [stats,    setStats]    = useState(null); // cleaning summary numbers
  const [preview,  setPreview]  = useState([]);  // up to 10 cleaned rows
  const [headers,  setHeaders]  = useState([]);  // column names for table
  const [cleaned,  setCleaned]  = useState([]);  // all cleaned rows (for download)
  const [fileName, setFileName] = useState("");
  const [loading,  setLoading]  = useState(false);

  const fileInputRef = useRef(null); // lets us reset the <input> after processing

  // ── Helper: set a green status message ───────────────────────────────────────
  const ok  = (msg) => { setStatus(msg); setIsError(false); };
  // ── Helper: set a red error message ──────────────────────────────────────────
  const err = (msg) => { setStatus(msg); setIsError(true);  };

  // ── Reset everything back to initial state ───────────────────────────────────
  function reset() {
    setStatus(""); setIsError(false); setStats(null);
    setPreview([]); setHeaders([]); setCleaned([]); setFileName("");
    setLoading(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  // ── Process the chosen file ──────────────────────────────────────────────────
  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    reset();
    setLoading(true);
    setFileName(file.name);

    const extension = file.name.split(".").pop().toLowerCase();

    // Validate extension
    if (!["csv", "xlsx", "xls"].includes(extension)) {
      err("❌ Unsupported file type. Please upload a CSV or XLSX file.");
      setLoading(false);
      return;
    }

    try {
      let rows = [];

      if (extension === "csv") {
        // ── Parse CSV with PapaParse ──────────────────────────────────────────
        rows = await new Promise((resolve, reject) => {
          Papa.parse(file, {
            header: true,        // first row becomes column names
            skipEmptyLines: true,
            complete: (result) => resolve(result.data),
            error:    (error)  => reject(error),
          });
        });
      } else {
        // ── Parse XLSX with SheetJS ───────────────────────────────────────────
        const buffer = await file.arrayBuffer(); // read file as binary
        const wb     = XLSX.read(buffer, { type: "array" });
        const ws     = wb.Sheets[wb.SheetNames[0]]; // use first sheet
        rows = XLSX.utils.sheet_to_json(ws, { defval: "" }); // empty cells → ""
      }

      if (!rows || rows.length === 0) {
        err("❌ File appears empty or could not be parsed.");
        setLoading(false);
        return;
      }

      // ── Run cleaning pipeline ─────────────────────────────────────────────
      const { cleaned: cleanedRows, stats: s } = cleanData(rows);

      if (cleanedRows.length === 0) {
        err("⚠️ After cleaning, no rows remain. Check your file.");
        setLoading(false);
        return;
      }

      // ── Store results in state ────────────────────────────────────────────
      const cols = Object.keys(cleanedRows[0]);
      setHeaders(cols);
      setCleaned(cleanedRows);
      setPreview(cleanedRows.slice(0, 10)); // show first 10 rows only
      setStats(s);
      ok(`✅ Done! ${s.final} rows ready after removing ${s.emptyRemoved} empty and ${s.dupesRemoved} duplicate rows.`);
    } catch (e) {
      console.error(e);
      err("❌ Something went wrong while processing the file. See console for details.");
    }

    setLoading(false);
  }

  // ── Generate and download the cleaned CSV ────────────────────────────────────
  function downloadCSV() {
    if (!cleaned.length) return;

    // PapaParse converts JSON → CSV string
    const csv  = Papa.unparse(cleaned);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url  = URL.createObjectURL(blob);

    // Create a hidden anchor and click it to trigger download
    const a       = document.createElement("a");
    a.href        = url;
    a.download    = `cleaned_${fileName.replace(/\.(csv|xlsx|xls)$/i, "")}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url); // free memory
  }

  // ── Render ───────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-8">

      {/* ── Drop Zone / File Input ── */}
      <div
        className="relative border-2 border-dashed border-forge-orange/60 rounded-2xl p-8 text-center
                   bg-forge-steel/40 hover:bg-forge-steel/70 transition-colors cursor-pointer
                   hover:border-forge-orange"
        onClick={() => fileInputRef.current?.click()}
      >
        {/* Hidden actual file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,.xlsx,.xls"
          onChange={handleFile}
          className="hidden"
          aria-label="Upload CSV or XLSX file"
        />

        {/* Upload icon */}
        <div className="text-5xl mb-3">📂</div>
        <p className="font-display text-2xl text-forge-orange tracking-wider">
          {loading ? "PROCESSING…" : "TAP TO UPLOAD"}
        </p>
        <p className="text-sm text-gray-400 mt-1">CSV or XLSX · max ~10 MB</p>

        {/* Loading spinner */}
        {loading && (
          <div className="mt-4 flex justify-center">
            <span className="inline-block w-6 h-6 border-4 border-forge-orange border-t-transparent
                             rounded-full animate-spin" />
          </div>
        )}
      </div>

      {/* ── Status message ── */}
      {status && (
        <p
          className={`rounded-xl px-4 py-3 text-sm font-medium border
            ${isError
              ? "bg-red-900/30 border-red-500 text-red-300"
              : "bg-green-900/30 border-green-500 text-green-300"}`}
        >
          {status}
        </p>
      )}

      {/* ── Stats summary ── */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          {[
            { label: "Original",  value: stats.original   },
            { label: "Empty Removed", value: stats.emptyRemoved },
            { label: "Dupes Removed", value: stats.dupesRemoved },
            { label: "Final Rows",    value: stats.final   },
          ].map(({ label, value }) => (
            <div key={label}
              className="bg-forge-steel/60 border border-white/10 rounded-xl py-3 px-2">
              <p className="font-display text-3xl text-forge-orange">{value}</p>
              <p className="text-xs text-gray-400 mt-1">{label}</p>
            </div>
          ))}
        </div>
      )}

      {/* ── Preview table ── */}
      {preview.length > 0 && (
        <div>
          <h2 className="font-display text-xl text-forge-orange tracking-widest mb-3">
            PREVIEW · FIRST {preview.length} ROWS
          </h2>
          {/* Horizontal scroll on small screens */}
          <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="min-w-full text-sm">
              <thead className="bg-forge-orange/90 text-forge-dark">
                <tr>
                  {headers.map((h) => (
                    <th key={h}
                      className="px-4 py-2 text-left font-semibold uppercase tracking-wide whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {preview.map((row, i) => (
                  <tr key={i}
                    className={i % 2 === 0 ? "bg-forge-steel/30" : "bg-forge-steel/60"}>
                    {headers.map((h) => (
                      <td key={h} className="px-4 py-2 text-gray-200 whitespace-nowrap">
                        {row[h] ?? "—"}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── Action buttons ── */}
      {cleaned.length > 0 && (
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Download button */}
          <button
            onClick={downloadCSV}
            className="flex-1 bg-forge-orange hover:bg-orange-500 active:scale-95
                       text-white font-display text-xl tracking-widest
                       py-4 rounded-2xl transition-all shadow-lg shadow-forge-orange/30"
          >
            ⬇ DOWNLOAD CLEANED CSV
          </button>

          {/* Reset button */}
          <button
            onClick={reset}
            className="sm:w-40 border border-white/20 hover:border-white/60 text-gray-300
                       font-body text-sm py-4 rounded-2xl transition-all"
          >
            Upload new file
          </button>
        </div>
      )}

      {/* ── WhatsApp CTA ── */}
      <a
        href={`https://wa.me/${WHATSAPP_NUMBER}?text=Hi%2C%20I%20need%20help%20with%20SovereignForge%20data%20cleaning`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-3 w-full py-4 rounded-2xl
                   bg-green-600 hover:bg-green-500 active:scale-95 transition-all
                   text-white font-display text-xl tracking-wider shadow-lg shadow-green-900/40"
      >
        {/* WhatsApp icon via SVG */}
        <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white" xmlns="http://www.w3.org/2000/svg">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15
                   -.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463
                   -2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606
                   .134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371
                   -.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51
                   -.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016
                   -1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487
                   .709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719
                   2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
          <path d="M12.004 2C6.477 2 2 6.477 2 12.004c0 1.771.463 3.431 1.27 4.876L2 22l5.273
                   -1.239A9.954 9.954 0 0012.004 22C17.523 22 22 17.523 22 12.004 22 6.477
                   17.523 2 12.004 2zm0 18.214a8.21 8.21 0 01-4.187-1.144l-.3-.178-3.13.735
                   .78-2.966-.196-.305A8.207 8.207 0 013.786 12c0-4.532 3.686-8.218 8.218
                   -8.218 4.533 0 8.22 3.686 8.22 8.218 0 4.533-3.687 8.214-8.22 8.214z"/>
        </svg>
        CHAT ON WHATSAPP
      </a>

    </div>
  );
}
