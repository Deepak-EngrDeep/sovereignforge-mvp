/** @type {import('next').NextConfig} */
const nextConfig = {
  // No special server-side config needed — everything is client-side
};

module.exports = nextConfig;
