# ⚙️ SovereignForge MVP — CSV / XLSX Cleaner for Small Factories

A **100% client-side** Next.js 14 web app that cleans messy factory customer data.
No backend. No server. Your data never leaves your device.

---

## ✨ What It Does

| Step | Action |
|------|--------|
| 1 | Upload a CSV or Excel (.xlsx) file |
| 2 | Empty rows are removed |
| 3 | Duplicate rows (same phone OR same name+product) are removed |
| 4 | Customer names → `Customer_001`, `Customer_002`… |
| 5 | Phone numbers → `XXXXXX1234` (last 4 digits kept) |
| 6 | Preview up to 10 cleaned rows |
| 7 | Download the cleaned CSV |

---

## 📁 File Structure

```
SovereignForge-MVP/
├── app/
│   ├── layout.js          ← Root HTML layout (fonts, metadata)
│   ├── page.js            ← Main page (instructions + uploader)
│   └── globals.css        ← Tailwind base styles
├── components/
│   └── FileUploader.jsx   ← All upload / parse / preview / download UI
├── utils/
│   └── cleaner.js         ← Pure data-cleaning functions
├── public/
│   └── favicon.svg        ← App icon
├── next.config.js
├── tailwind.config.js
├── postcss.config.js
├── package.json
└── README.md              ← You are here
```

---

## 🖥️ Run Locally (Development)

### Prerequisites
- [Node.js 18+](https://nodejs.org/) installed on your computer
- A terminal / command prompt

### Steps

```bash
# 1. Enter the project folder
cd SovereignForge-MVP

# 2. Install dependencies (takes ~1 minute on first run)
npm install

# 3. Start the development server
npm run dev

# 4. Open your browser at:
#    http://localhost:3000
```

To stop the server, press `Ctrl + C` in the terminal.

---

## 🚀 Deploy to Vercel (Free) — Step by Step

Vercel is the easiest way to put this app on the internet for free.

### Method A — Vercel Dashboard (No CLI needed, recommended for non-developers)

#### Step 1 — Create a free Vercel account
Go to [https://vercel.com](https://vercel.com) and sign up with GitHub, GitLab, or email.

#### Step 2 — Push your code to GitHub
1. Go to [https://github.com/new](https://github.com/new)
2. Create a new **private** repository called `sovereignforge-mvp`
3. Upload all the project files (drag-and-drop the folder in GitHub's UI, or use Git)

```bash
# If you use Git in terminal:
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/sovereignforge-mvp.git
git push -u origin main
```

#### Step 3 — Import into Vercel
1. Go to [https://vercel.com/new](https://vercel.com/new)
2. Click **"Import Git Repository"**
3. Select your `sovereignforge-mvp` repo
4. Leave all settings as-is (Vercel auto-detects Next.js)
5. Click **"Deploy"**

#### Step 4 — Wait ~60 seconds
Vercel builds and deploys automatically. You get a live URL like:
```
https://sovereignforge-mvp.vercel.app
```

---

### Method B — Vercel CLI (for developers comfortable with terminal)

```bash
# Install Vercel CLI globally
npm install -g vercel

# From inside the project folder:
vercel

# Follow the prompts (press Enter to accept defaults)
# Your app goes live immediately with a URL printed in the terminal
```

---

## ✏️ Customisation Checklist

| What to change | File | What to look for |
|----------------|------|-----------------|
| WhatsApp number | `components/FileUploader.jsx` | `const WHATSAPP_NUMBER = "91XXXXXXXXXX"` |
| App name / tagline | `app/page.js` | The `<h1>` and `<p>` in the hero section |
| Brand colour | `tailwind.config.js` | `forge.orange: "#E85D04"` |
| Cleaning rules | `utils/cleaner.js` | `removeDuplicates()` and `maskPersonalData()` |

---

## 📋 Expected CSV Column Names

The cleaner looks for these column names (case-insensitive):

- `name` — customer / buyer name (will be masked)
- `phone` — mobile number (will be masked)
- `product` — product ordered (used for duplicate detection)
- Any other columns (quantity, city, date…) are passed through unchanged

---

## 🔒 Privacy Note

All processing happens **inside the user's web browser** using JavaScript.
No data is sent to any server. The cleaned file is generated in-browser and
downloaded directly to the user's device.

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| [Next.js 14](https://nextjs.org/) | React framework |
| [Tailwind CSS](https://tailwindcss.com/) | Utility-first styling |
| [PapaParse](https://www.papaparse.com/) | CSV parsing & generation |
| [SheetJS (xlsx)](https://sheetjs.com/) | Excel file parsing |
| [Vercel](https://vercel.com/) | Free hosting |

---

*Built with ❤️ for small factory owners who just want clean data.*
