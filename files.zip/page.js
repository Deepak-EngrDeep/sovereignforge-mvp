// ─────────────────────────────────────────────────────────────────────────────
// app/page.js  ·  SovereignForge MVP
// This is the only "page" in the app. It is purely client-side — no server
// calls, no API keys. Everything runs in the user's browser.
// ─────────────────────────────────────────────────────────────────────────────
"use client";

import FileUploader from "../components/FileUploader";

// ── Example rows shown in the instructions card ───────────────────────────────
const EXAMPLE_ROWS = [
  { name: "Ramesh Kumar", phone: "9876543210", product: "Steel Rod 10mm", quantity: 50,  city: "Pune"   },
  { name: "Priya Shah",   phone: "8765432109", product: "PVC Pipe 1in",   quantity: 120, city: "Surat"  },
  { name: "Ramesh Kumar", phone: "9876543210", product: "Steel Rod 10mm", quantity: 50,  city: "Pune"   }, // duplicate
  { name: "",             phone: "",           product: "",                quantity: "",  city: ""       }, // empty row
];

export default function HomePage() {
  return (
    <main className="min-h-screen">

      {/* ── Top bar ─────────────────────────────────────────────────────────── */}
      <header className="border-b border-white/10 bg-forge-dark/80 backdrop-blur sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center gap-3">
          {/* Gear icon as brand mark */}
          <span className="text-2xl">⚙️</span>
          <span className="font-display text-2xl tracking-widest text-forge-orange">
            SOVEREIGNFORGE
          </span>
          <span className="hidden sm:inline text-xs text-gray-500 ml-auto">
            100% client-side · your data never leaves your device
          </span>
        </div>
      </header>

      {/* ── Main content ────────────────────────────────────────────────────── */}
      <div className="max-w-2xl mx-auto px-4 py-10 space-y-10">

        {/* ── Hero headline ── */}
        <section className="text-center space-y-3">
          <h1 className="font-display text-5xl sm:text-6xl tracking-widest leading-none">
            FACTORY{" "}
            <span className="text-forge-orange">DATA</span>{" "}
            CLEANER
          </h1>
          <p className="text-gray-400 text-base sm:text-lg">
            Upload your customer / order CSV or Excel file.
            We'll remove empty rows, deduplicate, and mask personal data — instantly.
          </p>
        </section>

        {/* ── Instructions card ─────────────────────────────────────────────── */}
        <section className="bg-forge-steel/50 border border-white/10 rounded-2xl p-5 space-y-4">
          <h2 className="font-display text-lg tracking-widest text-forge-orange">
            HOW IT WORKS
          </h2>

          {/* Step list */}
          <ol className="space-y-2 text-sm text-gray-300 list-none">
            {[
              "Your CSV/XLSX must have column headers in the first row.",
              "Supported column names (case-insensitive): name, phone, product, quantity, city — add more as needed.",
              "Empty rows are removed automatically.",
              "Duplicate rows (same phone OR same name+product) are removed — first occurrence is kept.",
              "Customer names are replaced with Customer_001, Customer_002 … and phone numbers are masked (last 4 digits kept).",
              "Download the cleaned file and use it safely.",
            ].map((step, i) => (
              <li key={i} className="flex gap-3">
                <span className="font-display text-forge-orange text-base w-5 flex-shrink-0">
                  {i + 1}.
                </span>
                <span>{step}</span>
              </li>
            ))}
          </ol>

          {/* Example CSV format */}
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">
              Example CSV format
            </p>
            <div className="overflow-x-auto rounded-xl border border-white/10">
              <table className="text-xs min-w-full">
                <thead className="bg-forge-orange/20 text-forge-orange">
                  <tr>
                    {Object.keys(EXAMPLE_ROWS[0]).map((h) => (
                      <th key={h} className="px-3 py-2 text-left whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {EXAMPLE_ROWS.map((row, i) => (
                    <tr key={i} className={i % 2 === 0 ? "bg-white/5" : ""}>
                      {Object.values(row).map((v, j) => (
                        <td key={j} className="px-3 py-1.5 text-gray-400 whitespace-nowrap">
                          {String(v) || <span className="italic text-gray-600">empty</span>}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-gray-600 mt-2">
              ↑ Row 3 is a duplicate of row 1. Row 4 is empty. Both will be removed.
            </p>
          </div>
        </section>

        {/* ── File uploader (all the real magic happens here) ── */}
        <FileUploader />

        {/* ── Footer ── */}
        <footer className="text-center text-xs text-gray-600 pb-6 space-y-1">
          <p>SovereignForge MVP · Built for small factories</p>
          <p>No data is uploaded to any server. Processing happens entirely in your browser.</p>
        </footer>
      </div>
    </main>
  );
}
