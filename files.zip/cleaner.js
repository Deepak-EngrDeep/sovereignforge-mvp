// ─────────────────────────────────────────────────────────────────────────────
// utils/cleaner.js
// All data-cleaning logic lives here. Pure functions — no UI dependencies.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * normaliseHeaders(rows)
 * Lower-cases every header key and trims whitespace so we can find
 * columns like "Name", "NAME", " name " reliably.
 */
function normaliseHeaders(rows) {
  return rows.map((row) => {
    const clean = {};
    Object.keys(row).forEach((key) => {
      clean[key.trim().toLowerCase()] = row[key];
    });
    return clean;
  });
}

/**
 * removeEmptyRows(rows)
 * Drop rows where EVERY cell is null, undefined, or an empty string.
 */
function removeEmptyRows(rows) {
  return rows.filter((row) => {
    return Object.values(row).some(
      (v) => v !== null && v !== undefined && String(v).trim() !== ""
    );
  });
}

/**
 * removeDuplicates(rows)
 * A row is considered a duplicate if:
 *   (a) its `phone` value matches a previously seen phone, OR
 *   (b) its `name` + `product` combination matches a previously seen pair.
 * The first occurrence is kept; later duplicates are removed.
 */
function removeDuplicates(rows) {
  const seenPhones   = new Set(); // tracks unique phone numbers
  const seenNameProd = new Set(); // tracks unique name+product pairs

  return rows.filter((row) => {
    const phone   = String(row.phone   || "").trim().toLowerCase();
    const name    = String(row.name    || "").trim().toLowerCase();
    const product = String(row.product || "").trim().toLowerCase();

    // Build composite key for name+product check
    const nameProdKey = `${name}||${product}`;

    // Check for duplicates
    const phoneDup   = phone    && seenPhones.has(phone);
    const namePrDup  = (name || product) && seenNameProd.has(nameProdKey);

    if (phoneDup || namePrDup) return false; // discard duplicate

    // Mark as seen
    if (phone)              seenPhones.add(phone);
    if (name || product)    seenNameProd.add(nameProdKey);

    return true; // keep this row
  });
}

/**
 * maskPersonalData(rows)
 * - Replaces each unique customer name with Customer_001, Customer_002 …
 * - Masks the first 6 characters of every phone number with XXXXXX
 *   (keeps the last 4 digits so staff can still distinguish customers).
 */
function maskPersonalData(rows) {
  const nameMap = new Map(); // original name → masked label
  let counter   = 1;

  return rows.map((row) => {
    const masked = { ...row }; // shallow copy so we don't mutate original

    // ── Name masking ──────────────────────────────────────────────────────────
    if (masked.name !== undefined) {
      const original = String(masked.name).trim();
      if (original !== "") {
        if (!nameMap.has(original)) {
          // Pad counter to 3 digits: 1 → "001"
          nameMap.set(original, `Customer_${String(counter).padStart(3, "0")}`);
          counter++;
        }
        masked.name = nameMap.get(original);
      }
    }

    // ── Phone masking ─────────────────────────────────────────────────────────
    if (masked.phone !== undefined) {
      const ph = String(masked.phone).trim();
      if (ph.length > 4) {
        // Keep last 4 digits; replace everything before with XXXXXX
        masked.phone = "XXXXXX" + ph.slice(-4);
      }
    }

    return masked;
  });
}

/**
 * cleanData(rows)
 * Master pipeline — call this with raw parsed rows.
 * Returns { cleaned, stats } where stats shows what was removed.
 */
export function cleanData(rows) {
  const step1 = normaliseHeaders(rows);
  const step2 = removeEmptyRows(step1);
  const step3 = removeDuplicates(step2);
  const step4 = maskPersonalData(step3);

  return {
    cleaned: step4,
    stats: {
      original:   rows.length,
      afterEmpty: step2.length,
      afterDupes: step3.length,
      final:      step4.length,
      emptyRemoved: rows.length   - step2.length,
      dupesRemoved: step2.length  - step3.length,
    },
  };
}
