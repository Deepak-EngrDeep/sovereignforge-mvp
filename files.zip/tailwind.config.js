/** @type {import('tailwindcss').Config} */
module.exports = {
  // Tell Tailwind which files to scan for class names
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
    "./app/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      // Custom brand colors for SovereignForge
      colors: {
        forge: {
          orange: "#E85D04",
          dark:   "#1A1A2E",
          steel:  "#16213E",
          light:  "#F5F5F0",
        },
      },
      fontFamily: {
        // Industrial slab-serif feel via Google Fonts (loaded in layout)
        display: ["'Bebas Neue'", "cursive"],
        body:    ["'DM Sans'", "sans-serif"],
      },
    },
  },
  plugins: [],
};
